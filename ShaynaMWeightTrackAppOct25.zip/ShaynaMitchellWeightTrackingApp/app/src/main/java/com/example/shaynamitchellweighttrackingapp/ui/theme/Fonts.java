package com.example.shaynamitchellweighttrackingapp.ui.theme;

import android.content.Context;
import android.graphics.Typeface;
import java.util.HashMap;
import java.util.Map;



public class Fonts {

    // Store Typeface
    private static final Map<String, Typeface> fontCache = new HashMap<>();

    // Constants
    public static final String MAISON_MONO = "maison_mono_regular.ttf";
    public static final String CUTIVE_MONO = "cutive_mono_regular.ttf";

    public static Typeface getFont(Context context, String fontName) {
        if (!fontCache.containsKey(fontName)) {
            Typeface typeface = Typeface.createFromAsset(context.getAssets(), "font/" + fontName);
            fontCache.put(fontName, typeface);
        }
        return fontCache.get(fontName);
    }
}











//Kotlin Code:
/*
package com.example.shaynamitchellweighttrackingapp.ui.theme


import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import com.example.shaynamitchellweighttrackingapp.R

// Declare your fonts here
val MaisonMono = FontFamily(Font(R.font.maison_mono_regular))
val CutiveMono = FontFamily(Font(R.font.cutive_mono_regular))
*/