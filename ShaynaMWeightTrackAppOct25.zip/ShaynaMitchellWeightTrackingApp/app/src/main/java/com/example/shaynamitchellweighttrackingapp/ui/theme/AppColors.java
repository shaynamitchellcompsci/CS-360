package com.example.shaynamitchellweighttrackingapp.ui.theme;

// Java Code:

import android.graphics.Color;

public class AppColors {

    // Define colors
    public static final int BLACK = Color.rgb(0, 0, 0); // #000000
    public static final int WHITE = Color.rgb(255, 255, 255); // #FFFFFF
    public static final int DARK_GRAY = Color.rgb(51, 51, 51); // #333333
    public static final int LIGHT_GRAY = Color.rgb(170, 170, 170); // #AAAAAA

    public static String getHexColor(int color) {
        return String.format("#%06X", (0xFFFFFF & color));
    }
}







//Kotlin Code:

/*
package com.example.shaynamitchellweighttrackingapp.ui.theme

import androidx.compose.ui.graphics.Color

// Define your colors here
val Black = Color(0xFF000000)
val White = Color(0xFFFFFFFF)
val DarkGray = Color(0xFF333333)
val LightGray = Color(0xFFAAAAAA)
*/