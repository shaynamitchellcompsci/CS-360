package com.example.shaynamitchellweighttrackingapp.ui.theme;

// Java Code:
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;


public class Theme {

    // Dark color palette
    public static final int PRIMARY_DARK = Color.BLACK;
    public static final int ON_PRIMARY_DARK = Color.WHITE;
    public static final int SECONDARY_DARK = Color.DKGRAY;

    // Light color palette
    public static final int PRIMARY_LIGHT = Color.WHITE;
    public static final int ON_PRIMARY_LIGHT = Color.BLACK;
    public static final int SECONDARY_LIGHT = Color.LTGRAY;

    // Fonts linked with Type.java
    private static Typeface maisonMono;
    private static Typeface cutiveMono;

    // Initialize fonts
    public static void initializeFonts(Context context) {
        try {
            maisonMono = Typeface.createFromAsset(
                    context.getAssets(), "font/maison_mono_regular.ttf");
            cutiveMono = Typeface.createFromAsset(
                    context.getAssets(), "font/cutive_mono_regular.ttf");
        } catch (Exception e) {
            e.printStackTrace(); // Log the error if fonts cannot be loaded
        }
    }

    // Getters for fonts
    public static Typeface getMaisonMono() {
        return maisonMono;
    }

    public static Typeface getCutiveMono() {
        return cutiveMono;
    }

    // Apply colors based on the theme
    public static void applyTheme(boolean isDarkTheme) {

        if (isDarkTheme) {

            System.out.println("Applying dark theme with primary color: " + PRIMARY_DARK);
        } else {

            System.out.println("Applying light theme with primary color: " + PRIMARY_LIGHT);
        }
    }
}








//Kotlin Code:


/*
package com.example.shaynamitchellweighttrackingapp.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color


import com.example.shaynamitchellweighttrackingapp.ui.theme.MaisonMono
import com.example.shaynamitchellweighttrackingapp.ui.theme.CutiveMono

import com.example.shaynamitchellweighttrackingapp.ui.theme.Black
import com.example.shaynamitchellweighttrackingapp.ui.theme.White
import com.example.shaynamitchellweighttrackingapp.ui.theme.DarkGray
import com.example.shaynamitchellweighttrackingapp.ui.theme.LightGray


private val DarkColorPalette = darkColorScheme(
    primary = Black,
    onPrimary = White,
    secondary = DarkGray
)

private val LightColorPalette = lightColorScheme(
    primary = White,
    onPrimary = Black,
    secondary = LightGray
)


val AppTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = MaisonMono,
        fontSize = 24.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = CutiveMono,
        fontSize = 18.sp
    )
)


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShaynaMitchellWeightTrackingAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(), // Toggle theme
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) {
        DarkColorPalette
    } else {
        LightColorPalette
    }

    //apply
    MaterialTheme(
        colorScheme = colors,
        typography = AppTypography,
        content = content
    )
}
*/