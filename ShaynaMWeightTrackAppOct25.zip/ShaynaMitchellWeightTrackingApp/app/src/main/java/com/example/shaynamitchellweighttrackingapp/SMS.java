package com.example.shaynamitchellweighttrackingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SMS extends AppCompatActivity {

    private ImageView draggableDot;
    private View smsSwitch;
    private Button goButton;
    private float dY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms); // Links to the SMS

        draggableDot = findViewById(R.id.draggableDot);
        smsSwitch = findViewById(R.id.smsSwitch);
        goButton = findViewById(R.id.goButton);

        // Initialize the draggable dot position based on saved preferences
        SharedPreferences preferences = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        boolean isSmsEnabled = preferences.getBoolean("sms_notifications", true); // Default to ON (true)

        // Set the initial position of the dot (UP = ON, DOWN = OFF)
        if (isSmsEnabled) {
            draggableDot.setY(smsSwitch.getY()); // Set to top position
        } else {
            draggableDot.setY(smsSwitch.getY() + smsSwitch.getHeight() - draggableDot.getHeight()); // Set to bottom position
        }

        // Handle draggable dot listener for dragging
        draggableDot.setOnTouchListener((v, event) -> {


            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dY = v.getY() - event.getRawY();  // Initialize dragging distance
                    break;
                case MotionEvent.ACTION_MOVE:
                    // Set limits for how far the dot can move
                    float newY = event.getRawY() + dY;
                    float minY = smsSwitch.getY();
                    float maxY = smsSwitch.getY() + smsSwitch.getHeight() - draggableDot.getHeight();
                    if (newY >= minY && newY <= maxY) {
                        draggableDot.setY(newY);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    // Snap the dot to the top (ON) or bottom (OFF) based on its final position
                    float halfwayPoint = smsSwitch.getY() + (smsSwitch.getHeight() / 2.0f);
                    if (draggableDot.getY() < halfwayPoint) {
                        // Snap to ON (top)
                        draggableDot.setY(smsSwitch.getY());
                        saveSmsPreference(true);
                        Toast.makeText(SMS.this, "SMS Notifications ON", Toast.LENGTH_SHORT).show();
                    } else {
                        // Snap to OFF (bottom)
                        draggableDot.setY(smsSwitch.getY() + smsSwitch.getHeight() - draggableDot.getHeight());
                        saveSmsPreference(false);
                        Toast.makeText(SMS.this, "SMS Notifications OFF", Toast.LENGTH_SHORT).show();
                    }
                    break;
            }
            return true;
        });

        // Go button click logic
        goButton.setOnClickListener(v -> {
            // Navigate to the weight log screen
            Intent intent = new Intent(SMS.this, WeightLogScreen.class);
            startActivity(intent);
        });
    }

    // Method to save SMS preference
    private void saveSmsPreference(boolean isEnabled) {
        SharedPreferences preferences = getSharedPreferences("sms_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("sms_notifications", isEnabled);
        editor.apply();
    }
}






